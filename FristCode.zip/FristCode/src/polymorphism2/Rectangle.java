package polymorphism2;

public class Rectangle extends Shape {
	double lenght, width;
	
	public Rectangle(double lenght, double width) {
		this.lenght = lenght;
		this.width = width;
	}
	
	@Override 
	double area() {
		System.out.println("Area for Rectangle :");
		 return lenght * width;
	}
}
