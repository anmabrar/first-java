package polymorphism2;

public class Shape {
	 double area() {
		 System.out.println("Shape area :");
		 return 0;
	}
}
