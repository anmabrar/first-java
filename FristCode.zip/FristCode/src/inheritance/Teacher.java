package inheritance;

public class Teacher extends Person {
	//name, age, displayInformation1
	String qualification;
	String subject;
	
	void displayInformation2() {
		displayInformation1();
		System.out.println("Qualification : "+qualification);
		System.out.println("Subject : "+subject);
	}
}
