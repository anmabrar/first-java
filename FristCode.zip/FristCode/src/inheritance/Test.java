package inheritance;

public class Test {
	public static void main(String[] args) {
		Teacher t1 = new Teacher();
		t1.name = "Salam";
		t1.age = 42;
		t1.qualification = "MSc in CSE";
		t1.subject = "CSE";
		t1.displayInformation2();
		
		System.out.println();
		
		Teacher t2 = new Teacher();
		t2.name = "Kalam";
		t2.age = 30;
		t2.qualification = "MSc in CSE";
		t2.subject = "CSE";
		t2.displayInformation2();
	}

}
