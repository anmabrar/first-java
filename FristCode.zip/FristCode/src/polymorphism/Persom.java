package polymorphism;

public class Persom {
	void display() {
		System.out.println("I am a person.");
	}

}
