package polymorphism;

public class Teacher extends Persom {
	@Override
	void display() {
		System.out.println("I am a Teacher.");
	}
}
