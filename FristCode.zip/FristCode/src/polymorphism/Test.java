package polymorphism;

public class Test {
	public static void main(String[] args) {
		Persom p = new Persom();
		p.display();
		p = new Teacher();
		p.display();
		p = new Student();
		p.display();
		
	}

}
