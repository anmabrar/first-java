package polymorphism;

public class Student extends Persom {
	@Override
	void display() {
		System.out.println("I am a Student.");
	}

}
