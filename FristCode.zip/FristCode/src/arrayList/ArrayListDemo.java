package arrayList;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList<Integer> number = new ArrayList<Integer>();
		System.out.println("Size = "+number.size());
		
		//array elements
		
		number.add(20);
		number.add(30);
		number.add(2, 50);
		
		// for each loop
		for(int x : number) {
			System.out.print(" "+x);
		}
		System.out.println();
		
		// array list size
		System.out.println("Size = "+number.size());
		
		//Iterator method 
		Iterator itr = number.iterator();
		while(itr.hasNext()) {
			System.out.println(" "+itr.next());
		}
		
		// General
		System.out.println(number);
		
		//contain
		boolean c = number.contains(20);
		System.out.println(c);
		
		//index check
		int position = number.indexOf(30);
		System.out.println(position);
		
		//set
		number.set(0, 25);
		System.out.println(number);
		
		//get
		int index = number.get(1);
		System.out.println(index);
				
		//remove
		number.remove(2); //index number
		System.out.println(number);
		
		//remove all
		number.removeAll(number);
		System.out.println(number);
		// clear all data
		number.clear();
		// is empty
		boolean b = number.isEmpty();
		System.out.println(b);
		

		

		
	}
}
