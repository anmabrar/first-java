package iterface;

public class Test {
	public static void main(String[] args) {
		Dog d = new Dog();
		d.eat();
	}

}
