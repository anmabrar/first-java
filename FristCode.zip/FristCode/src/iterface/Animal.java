package iterface;

public interface Animal {
	public abstract void eat();

}
