package boxVolume;

public class volumeBox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box b1 = new Box(10,10,10);
		Box b2 = new Box(20,30,10);
		
		b1.displyVol();
		b2.displyVol();
		

	}

}
