package boxVolume;

public class Box {
	
	double hight, width, depth;
	
	Box(double h, double w, double d) {
		hight = h;
		width = w;
		depth = d;
	}
	
	void displyVol() {
		double vol = hight * width * depth;
		System.out.println("Box volume is : "+vol);
	}

}
