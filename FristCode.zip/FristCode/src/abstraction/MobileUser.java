package abstraction;

abstract public class MobileUser {
	abstract void sendMessage();

}
