package abstraction;

public class Test {
	public static void main(String[] args) {
		MobileUser mu;
		
		mu =  new Rakib();
		mu.sendMessage();
		
		mu = new Sakib();
		mu.sendMessage();
	}

}
