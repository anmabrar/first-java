package abstraction;

public class Rakib extends MobileUser {
	@Override
	void sendMessage() {
		System.out.println("Hi! I am Rakib.");
	}
}
