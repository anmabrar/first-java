package abstraction;

public class Sakib extends MobileUser {
	@Override 
	void sendMessage() {
		 System.out.println("Hi! I am Sakib.");
	 }
}
