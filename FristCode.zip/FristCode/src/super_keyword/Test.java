package super_keyword;

public class Test {
	public static void main(String[] args) {
		Car volvoCar = new Car("Red",250.5,100000, 4);
		volvoCar.attribute();
	}

}
