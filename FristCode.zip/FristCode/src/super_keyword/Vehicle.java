package super_keyword;

public class Vehicle {
	String color;
	double weight;
	int price;
	
	public Vehicle( String c, double w, int p) {
		color = c;
		weight = w;
		price = p;
	}
	
	void attribute() {
		System.out.println("Color : "+color);
		System.out.println("Weight : "+weight);
		System.out.println("Price : "+price);
	}

}
