package super_keyword;

public class Car extends Vehicle {
	//color, weight, attribute()
	int gear;
	
	public Car(String c, double w, int p, int g) {
		super(c, w, p);
		gear = g;
	}
	
	@Override
	void attribute() {
		super.attribute();
		System.out.println("Gear : "+gear);
	}

}
