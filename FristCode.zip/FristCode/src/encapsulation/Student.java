package encapsulation;

public class Student {
	private String name;
	private int roll;
	private String subject;
	private String university;
	
	
	public void setStudent(String name, int roll, String subject, String university) {
		this.name = name;
		this.subject = subject;
		this.university = university;
		this.roll =roll;
	}
	
	public void getStudent() {
		System.out.println("Student Name : "+name);
		System.out.println("Roll : "+roll);
		System.out.println("Subject : "+subject);
		System.out.println("University : "+university);

	}

}
