package encapsulation;

public class TestStudent {

	public static void main(String[] args) {
		Student s1 = new Student();
		s1.setStudent("Abrar", 10,"CSE", "UAP");
		s1.getStudent();
		System.out.println();
		Student s2 = new Student();
		s2.setStudent("Sojol", 15,"CSE", "SEU");
		s2.getStudent();

	}

}
